<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>IT Technologies</title>
    <style>
        /* Reset styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body and background */
        body {
            font-family: Arial, sans-serif;
            color: #333;
            background: linear-gradient(to right, #004e92, #000428);
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Header and navigation */
        header {
            width: 100%;
            background: #111;
            padding: 1rem 0;
        }

        nav {
            display: flex;
            justify-content: center;
        }

        nav a {
            color: #fff;
            margin: 0 15px;
            text-decoration: none;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #00aaff;
        }

        /* Main content area */
        .content {
            width: 80%;
            max-width: 1200px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        /* Title and description */
        h1 {
            font-size: 2.5rem;
            color: #004e92;
            margin-bottom: 1rem;
        }

        p {
            font-size: 1.1rem;
            line-height: 1.6;
            margin-bottom: 1.5rem;
        }

        /* Button styles */
        .btn {
            display: inline-block;
            background-color: #004e92;
            color: #fff;
            padding: 10px 20px;
            margin-top: 1rem;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #003366;
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
        </nav>
    </header>
    <div class="content">
        <h1>Welcome to IT Technologies</h1>
        <p>Empowering businesses with innovative IT solutions, IT Technologies offers expert cybersecurity, system design, and IT consultancy services. Our team is committed to advancing technological progress and creating secure, efficient digital environments for organizations worldwide.</p>
    </div>
</body>
</html>
