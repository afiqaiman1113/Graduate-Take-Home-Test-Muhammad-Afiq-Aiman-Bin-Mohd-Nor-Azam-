const mysql = require('mysql');

const db = mysql.createConnection({
    host: 'localhost',
    port: 3307,          // Add this line for port 3307
    user: 'root',
    password: '',        // Your MySQL password if any
    database: 'user_system'
});

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Database');
});

module.exports = db;
