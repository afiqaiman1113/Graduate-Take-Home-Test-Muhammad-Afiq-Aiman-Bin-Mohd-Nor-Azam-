<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form input values
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare data for the API request
    $data = array(
        'username' => $username,
        'email' => $email,
        'password' => $password
    );

    // Initialize cURL session to interact with Node.js API
    $ch = curl_init('http://localhost:3000/register'); // Node.js API URL
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json'
    ));

    // Execute cURL request and capture response
    $response = curl_exec($ch);

    // Check for cURL errors
    if ($response === false) {
        echo "Error: " . curl_error($ch);
    } else {
        $responseData = json_decode($response, true);
        if (isset($responseData['message'])) {
            echo "<script>alert('" . $responseData['message'] . "'); window.location.href = 'login.php';</script>";
        } else {
            echo "<script>alert('Error: Unable to register.'); window.location.href = 'register.php';</script>";
        }
    }

    // Close cURL session
    curl_close($ch);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - IT Technologies</title>
    <style>
        /* Reset styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body and background */
        body {
            font-family: Arial, sans-serif;
            color: #333;
            background: linear-gradient(to right, #004e92, #000428);
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Header and navigation */
        header {
            width: 100%;
            background: #111;
            padding: 1rem 0;
        }

        nav {
            display: flex;
            justify-content: center;
        }

        nav a {
            color: #fff;
            margin: 0 15px;
            text-decoration: none;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #00aaff;
        }

        /* Main content area */
        .register-container {
            width: 100%;
            max-width: 400px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        /* Form styling */
        h2 {
            color: #004e92;
            margin-bottom: 1rem;
        }

        label {
            font-weight: bold;
            margin-top: 1rem;
            display: block;
            color: #333;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
        }

        /* Button styles */
        .btn {
            display: inline-block;
            background-color: #004e92;
            color: #fff;
            padding: 10px 20px;
            margin: 0.5rem;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            cursor: pointer;
            border: none;
            font-size: 1rem;
            width: 100%;
        }

        .btn:hover {
            background-color: #003366;
        }

        /* Responsive design */
        @media (max-width: 500px) {
            .register-container {
                width: 90%;
            }

            nav a {
                font-size: 0.9rem;
                margin: 0 10px;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
        </nav>
    </header>
    <div class="register-container">
        <h2>Create Your Account</h2>
        <form method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" class="btn">Register</button>
        </form>
        <p>Already have an account? <a href="login.php" class="btn">Login</a></p>
    </div>
</body>
</html>
