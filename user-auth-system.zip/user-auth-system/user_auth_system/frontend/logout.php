<button onclick="logout()">Logout</button>
<script>
    function logout() {
        fetch('http://localhost:3000/logout', { method: 'POST' })
        .then(response => response.text())
        .then(data => alert(data));
    }
</script>
