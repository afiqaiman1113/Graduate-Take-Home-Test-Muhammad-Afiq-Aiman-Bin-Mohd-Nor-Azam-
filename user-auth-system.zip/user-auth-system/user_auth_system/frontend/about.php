<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - IT Technologies</title>
    <style>
        /* Reset styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body and background */
        body {
            font-family: Arial, sans-serif;
            color: #333;
            background: linear-gradient(to right, #004e92, #000428);
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Header and navigation */
        header {
            width: 100%;
            background: #111;
            padding: 1rem 0;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
        }

        nav {
            display: flex;
            justify-content: center;
        }

        nav a {
            color: #fff;
            margin: 0 15px;
            text-decoration: none;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #00aaff;
        }

        /* Main content area */
        .about-container {
            width: 90%;
            max-width: 900px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.15);
            text-align: center;
        }

        /* Section styling */
        h2 {
            color: #004e92;
            margin-bottom: 1rem;
            font-size: 2rem;
        }

        .section {
            margin-bottom: 2rem;
            padding: 1.5rem;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .section h3 {
            color: #003366;
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }

        .section p {
            font-size: 1rem;
            color: #333;
            line-height: 1.6;
            text-align: left;
        }

        /* Service box styling */
        .service-box {
            padding: 1rem;
            border-radius: 8px;
            color: #fff;
            font-size: 1rem;
            margin-bottom: 1rem;
            font-weight: bold;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.15);
        }

        .service-box:nth-child(1) { background-color: #007bbd; }
        .service-box:nth-child(2) { background-color: #004e92; }
        .service-box:nth-child(3) { background-color: #007bbd; }
        .service-box:nth-child(4) { background-color: #004e92; }

        /* Responsive design */
        @media (max-width: 768px) {
            h2 {
                font-size: 1.5rem;
            }

            .section h3 {
                font-size: 1.3rem;
            }

            .about-container {
                padding: 1.5rem;
            }
        }

        @media (max-width: 500px) {
            nav a {
                font-size: 0.9rem;
                margin: 0 10px;
            }

            .about-container {
                width: 95%;
                padding: 1rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
        </nav>
    </header>

    <div class="about-container">
        <h2>About IT Technologies</h2>

        <div class="section mission">
            <h3>Our Mission</h3>
            <p>Our mission is to harness the power of technology to create secure, efficient, and scalable solutions that drive success and innovation for our clients. We strive to be a trusted partner for businesses looking to adapt and thrive in an increasingly digital world.</p>
        </div>

        <div class="section values">
            <h3>Our Values</h3>
            <p><strong>Innovation:</strong> We believe in the transformative power of technology. Our team is constantly exploring new advancements and methodologies to offer our clients the latest in IT innovation.</p>
            <p><strong>Integrity:</strong> Trust is at the core of what we do. We prioritize transparency and ethical practices to build long-term partnerships with our clients.</p>
            <p><strong>Excellence:</strong> Quality is non-negotiable at IT Technologies. We hold ourselves to high standards in every aspect of our work to ensure exceptional results for our clients.</p>
        </div>

        <div class="section services">
            <h3>Our Services</h3>
            <div class="service-box">Cybersecurity Solutions: From penetration testing to threat monitoring, we provide robust cybersecurity services that help businesses protect their digital assets.</div>
            <div class="service-box">Cloud Solutions: We assist businesses in leveraging cloud technology to improve efficiency, scalability, and flexibility in their operations.</div>
            <div class="service-box">Data Management and Analytics: Our team helps clients make data-driven decisions through advanced data analytics and secure data management.</div>
            <div class="service-box">Software Development: Tailored software solutions to meet the unique needs of each business, enhancing functionality and user experience.</div>
        </div>

        <div class="section why-choose">
            <h3>Why Choose IT Technologies?</h3>
            <p>IT Technologies is more than just an IT provider. We are your strategic partner in technology, dedicated to helping you achieve your business goals. Our team is comprised of industry experts with a deep understanding of IT trends and challenges, ready to deliver customized solutions that fit your needs.</p>
        </div>
    </div>
</body>
</html>
