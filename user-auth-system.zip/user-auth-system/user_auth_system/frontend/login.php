<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - IT Technologies</title>
    <style>
        /* Reset styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body and background */
        body {
            font-family: Arial, sans-serif;
            color: #333;
            background: linear-gradient(to right, #004e92, #000428);
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Header and navigation */
        header {
            width: 100%;
            background: #111;
            padding: 1rem 0;
        }

        nav {
            display: flex;
            justify-content: center;
        }

        nav a {
            color: #fff;
            margin: 0 15px;
            text-decoration: none;
            font-size: 1.1rem;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #00aaff;
        }

        /* Main content area */
        .login-container {
            width: 100%;
            max-width: 400px;
            margin: 2rem auto;
            background: rgba(255, 255, 255, 0.9);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        /* Login form styling */
        h2 {
            color: #004e92;
            margin-bottom: 1rem;
        }

        label {
            font-weight: bold;
            margin-top: 1rem;
            display: block;
            color: #333;
        }

        input[type="username"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
        }

        /* Button styles */
        .button-container {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .btn {
            background-color: #004e92;
            color: #fff;
            padding: 10px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            cursor: pointer;
            border: none;
            font-size: 1rem;
            width: 100%;
            text-align: center;
        }

        .btn:hover {
            background-color: #003366;
        }

        /* Pop-up modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
        }

        .modal-content h3 {
            color: #004e92;
        }

        .modal .btn-close {
            background-color: #f44336;
            border: none;
            padding: 10px 20px;
            margin-top: 20px;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }

        /* Responsive design */
        @media (max-width: 500px) {
            .login-container {
                width: 90%;
            }

            nav a {
                font-size: 0.9rem;
                margin: 0 10px;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Home</a>
            <a href="about.php">About</a>
            <a href="register.php">Register</a>
            <a href="login.php">Login</a>
        </nav>
    </header>
    <div class="login-container" id="loginContainer">
        <h2>Login to Your Account</h2>
        <form id="loginForm" onsubmit="return handleLogin(event)">
            <label for="username">Username:</label>
            <input type="username" id="username" name="username" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <div class="button-container">
                <button type="submit" class="btn">Login</button>
                <a href="register.php" class="btn">Register</a>
            </div>
        </form>
    </div>

    <!-- Modal for Login Success -->
    <div class="modal" id="successModal">
        <div class="modal-content">
            <h3>Login Successful</h3>
            <p>Welcome, <span id="loggedInUser"></span>!</p> <!-- Display username here -->
            <button class="btn-close" onclick="closeModal()">Close</button>
            <button id="logoutButton" class="btn" onclick="logout()" style="display: none;">Logout</button> <!-- Logout button -->
        </div>
    </div>

    <script>
        // Mock login success function to trigger the modal
        function handleLogin(event) {
            event.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            // Here, you can add your actual login validation. For now, we assume success.
            if (username && password) {
                // Store the username in the session (you would typically do this on the server-side)
                sessionStorage.setItem("username", username);

                // Display modal with the username
                document.getElementById("successModal").style.display = "flex"; // Show modal on success
                document.getElementById("loggedInUser").textContent = username;
                document.getElementById("loginForm").style.display = "none"; // Hide login form
                document.getElementById("logoutButton").style.display = "block"; // Show logout button
            } else {
                alert("Please enter valid credentials.");
            }
        }

        // Close the modal
        function closeModal() {
            document.getElementById("successModal").style.display = "none";
            // Optionally, redirect the user to another page after closing the modal
            window.location.href = "about.php";
        }

        // Logout function
        function logout() {
            // Clear the session storage and any user data
            sessionStorage.removeItem("username");

            // Hide the modal and login form, and redirect to home page
            document.getElementById("successModal").style.display = "none";
            window.location.href = "index.php"; // Redirect to homepage after logout
        }

        // Check if user is already logged in (using sessionStorage)
        window.onload = function () {
            const username = sessionStorage.getItem("username");
            if (username) {
                document.getElementById("successModal").style.display = "flex"; // Show modal
                document.getElementById("loggedInUser").textContent = username;
                document.getElementById("loginForm").style.display = "none"; // Hide login form
                document.getElementById("logoutButton").style.display = "block"; // Show logout button
            }
        }
    </script>
</body>
</html>
